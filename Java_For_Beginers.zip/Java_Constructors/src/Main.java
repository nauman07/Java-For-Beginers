import java.util.Scanner;

public class Main {
  int modelYear;
  String modelName;

  public Main(int year, String name) {
    modelYear = year;
    modelName = name;
  }

  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int a = sc.nextInt();
	String c = sc.nextLine();
	String b = sc.nextLine();
    Main myCar = new Main(a,b);
    System.out.println(myCar.modelYear + " " + myCar.modelName);
  }
}