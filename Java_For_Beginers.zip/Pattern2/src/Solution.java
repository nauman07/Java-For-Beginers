import java.util.Scanner;

public class Solution {
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String[] arr ={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
		for(int i = 1; i<=n;i++) {
			for(int j = i; j>=1;j--) {
				int a = i-1;
				System.out.print(arr[a]);
			}
			System.out.print("\n");
		}
	}

}
