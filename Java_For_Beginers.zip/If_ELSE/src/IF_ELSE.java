import java.util.Scanner;

public class IF_ELSE {

	public IF_ELSE() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a ");
		int a = sc.nextInt();
		System.out.print("Enter b ");
		int b = sc.nextInt();
		System.out.print("Enter c ");
		int c = sc.nextInt();
		if(a>b) 
		{
			if (a>c) 
			{
			System.out.print("a is the greatest");
			}
			else 
			{
			System.out.print("c is the greatest");
			}

		} 
		else if (b>a) 
		{
			if(b>c) 
			{
				System.out.print("b is the greatest");
			}
			else 
			{
				System.out.print("c is the greatest");
			}
		} 
		else 
		{
			System.out.print("All are equal"+"\n");
		}
		int time = 20;
		String result = (time < 18) ? "Good day." : "Good evening.";
		System.out.println(result);
}
}