
public class Main {
	int x=5;
	public Main() {
		// TODO Auto-generated constructor stub
	}
	  public static void main(String[] args) {
		    Main myObj = new Main();
		    Second myObj1 = new Second();
		    System.out.println(myObj.x);
		    System.out.println(myObj1.x);
		    System.out.println(myObj1.y);
		  }

}
