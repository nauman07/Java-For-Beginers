
public class Second {
	int x=5;
	int y=10;
	public Second() {
		// TODO Auto-generated constructor stub
	}

}
