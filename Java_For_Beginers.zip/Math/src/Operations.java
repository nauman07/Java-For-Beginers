import java.util.Scanner;

public class Operations {

	public Operations() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the numbers"+"\n");
		int a= sc.nextInt();
		int b= sc.nextInt(); 
		//Finding Max
		System.out.print("Max is "+ Math.max(a,b)+"\n");
		// Finding min
		System.out.print("Min is "+ Math.min(a,b)+"\n");
		//Finding Square root
		System.out.print("Enter the number to find Square root "+"\n");
		int c = sc.nextInt();
		System.out.print("Sqrt is"+ Math.sqrt(c)+"\n");
		//Finding Absolute
		float d = sc.nextFloat();
		System.out.print(Math.abs(d)+"\n");
		//Random Numbers
		//Math.random() returns a random number between 0.0 (inclusive), and 1.0 (exclusive):
		System.out.print(Math.random()+"\n");
		//getting random int
		int randomNum = (int)(Math.random() * 101);  // 0 to 100
		System.out.print(randomNum+"\n");
		// ceil 
		System.out.print(Math.ceil(d)+"\n");
		//floor
		System.out.print(Math.floor(d)+"\n");
	}

}
