import java.util.Scanner;

public class Array {

	public Array() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of array");
		int a = sc.nextInt();
		int[] arr = new int[a];
		for(int i = 0; i<a;i++) {
			arr[i]=sc.nextInt();
		}
		for (int i : arr) {
			System.out.print(i+"\n");
		}
		System.out.println("Enter the size for the multidimensional array ");
		int m = sc.nextInt();
		int n = sc.nextInt();
		int[][] marr= new int[m][n];
		for(int i = 0; i<m;i++) {
			marr[i] = new  int[n];
			for(int j = 0 ; j<n ; j++) {
			marr[i][j]=sc.nextInt();
			}
		}
		//int[][] marr= {{1,2,3},{4,5,6},{7,8,9}};
		for(int[] i: marr) {
			System.out.print("\n");
			for (int j: i) {
				System.out.print(j+"\t");
			}
		}
		
	}

}
