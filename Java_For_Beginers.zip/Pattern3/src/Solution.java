import java.util.Scanner;

public class Solution {
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String[] arr ={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
		int i =0;
		while(i<n) {
				int a = i+1;
				int b = i + a;
				int j = i;
				while(j<b) {
					System.out.print(arr[j]);
					j++;
				}
				System.out.print("\n");
				i++;
		}
	}

}
