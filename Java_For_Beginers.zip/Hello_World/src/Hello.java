import java.util.Scanner;

public class Hello {

	public Hello() {
		// TODO Auto-generated constructor stub
		System.out.println("Hello World");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
		System.out.print("Enter first number- ");  
		int a= sc.nextInt();  
		System.out.print("Enter second number- ");  
		int b= sc.nextInt();  
		System.out.print("Enter third number- ");  
		int c= sc.nextInt();  
		int d=a+b+c;  
		System.out.println("Total= " +d);  
		System.out.print("Enter a string: ");  
		String str= sc.nextLine();   //reads string 
		System.out.print("You have entered: "+str);
	}

}

