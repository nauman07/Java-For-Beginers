import java.util.Scanner;

public class For_loop_first {

	public For_loop_first() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter number to find factorial");  
		int a= sc.nextInt();
		int fact;
		fact=1;
		for (int i = 1; i<= a; i++) {
			fact = fact *i;
	}
		System.out.println(fact);

}
}	
