
public class Assembler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateFile.main(null);
		WriteToFile.main(null);
		ReadFile.main(null);
		GetFileInfo.main(null);
		DeleteFile.main(null);
		DeleteFolder.main(null);
		
	}

}
