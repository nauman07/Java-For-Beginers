import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i = n;
		while(i>=1) {
			int j =1;
			while(j<=i) {
				System.out.print(i);
				j++;
			}
			System.out.print("\n");
			i--;
		}

	}

}
