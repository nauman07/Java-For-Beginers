import java.util.Scanner;

public class Type_Casting {

	public Type_Casting() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter a string: "); 
		String str= sc.nextLine();
		int a=Integer.parseInt(str);
		float b=a;
		System.out.print("This is the string"+str+"\n");
		System.out.print("This is the int"+a+"\n");
		System.out.print("This is the float"+b);
	}

}
