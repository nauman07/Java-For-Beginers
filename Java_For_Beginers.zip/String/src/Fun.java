import java.util.Scanner;

public class Fun {

	public Fun() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a string: "); 
		String str= sc.nextLine();
		//Calculating the length
		System.out.println("The length of the txt string is: " + str.length());
		//Changing to uppercase
		System.out.println(str.toUpperCase());
		//Changing to lowercase
		System.out.println(str.toLowerCase());
		//Finding a Character in a String
		//The indexOf() method returns the index (the position) of the first occurrence of a specified text in a string (including whitespace):
		System.out.print("Enter a string to find: "); 
		String s= sc.nextLine();
		System.out.println(str.indexOf(s));
		//Concat
		String x = "10";
		String y = "20";
		String z = x + y;
		System.out.println(z);
		String firstName = "John ";
		String lastName = "Doe";
		System.out.println(firstName.concat(lastName));
	}

}
