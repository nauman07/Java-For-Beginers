import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Second myobj= new Second();
		System.out.println("Enter Information in the following fashion First Name then Age Then Salary");
		int ans;
		do {
			myobj.name=sc.nextLine();
			myobj.age=sc.nextInt();
			myobj.salary=sc.nextInt();
			System.out.println("You have Entered "+"\nName "+myobj.name+"\nAge "+myobj.age+"\nSalary "+myobj.salary);
			System.out.println("\n Do you want to input more info If Press 1 otherwise Press 0");
			//String ans1 = sc.nextLine();
			ans = sc.nextInt();
			System.out.println(ans);
		} while(ans==1);
		sc.close();
		System.out.println("Thanks for using our system");
	}

}
