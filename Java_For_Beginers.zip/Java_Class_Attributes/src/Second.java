
public class Second {
			int age;
			int salary;
			String name;
}
