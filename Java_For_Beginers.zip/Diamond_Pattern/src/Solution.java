import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println("*");
		int i = 1;
		while(i<n) {
			int j = 1;
			System.out.print("*");
			while(j<i) {
			System.out.print(j);
			j++;
			}
			while(j>=1) {
				System.out.print(j);
				j--;
			}
			System.out.print("*");
			System.out.print("\n");
			i++;
		}
		while(i>=1) {
			int j = 1;
			System.out.print("*");
			while(j<i) {
			System.out.print(j);
			j++;
			}
			while(j>=1) {
				System.out.print(j);
				j--;
			}
			System.out.print("*");
			System.out.print("\n");
			i--;
		}
		System.out.println("*");
	}

}
