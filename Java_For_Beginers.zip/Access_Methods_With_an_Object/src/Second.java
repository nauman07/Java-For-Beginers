
public class Second {
	  public void fullThrottle() {
		    System.out.println("The car is going as fast as it can!");
		  }

		  public void speed(int maxSpeed) {
		    System.out.println("Max speed is: " + maxSpeed);
		  }
}
