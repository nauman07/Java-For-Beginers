
public class Main {
	public static void main(String[] args) {
	    Second myCar = new Second();     // Create a myCar object
	    myCar.fullThrottle();      // Call the fullThrottle() method
	    myCar.speed(200);          // Call the speed() method
	  }
}
