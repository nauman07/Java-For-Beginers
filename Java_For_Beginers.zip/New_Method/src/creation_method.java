
public class creation_method {

	public creation_method() {
		// TODO Auto-generated constructor stub
	}
	public static int function(int a,int b) {
		System.out.print("So I occured"+"\n");
		System.out.print(a+b);
		return a+b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(function(5,5));
	}

}
