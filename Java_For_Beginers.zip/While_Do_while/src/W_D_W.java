import java.util.Scanner;

public class W_D_W {

	public W_D_W() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the numbers to find ");
		int a= sc.nextInt();
		int fact = 1;
		while (a>0) {
		  System.out.println(a);
		  fact=fact*a;
		  a--;
		}
		System.out.print(fact);
		int b= sc.nextInt();
		int fact1 = 1;
		do {
			fact1=fact1*b;
			b--;
		}while(b>0);
		System.out.print(fact1);
	}

}
