import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class Main {
	ArrayList<String> emp_name = new ArrayList<String>();
	ArrayList<Integer> emp_no = new ArrayList<Integer>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		while(true) {
			int a = menu();
			if(a==1) {
				adder();
			}else if(a==2) {
				viewer();
			}else if(a==3) {
				remover();
			}else {
				System.out.println("Enetr proper choice");
			}
		}
	}
	private static void remover() {
		// TODO Auto-generated method stub
		Main myobj= new Main();
		System.out.println("Enter the index number of employeee you want to remove");
		Scanner sc = new Scanner(System.in);
		int ind = sc.nextInt();
		myobj.emp_name.remove(ind);
		myobj.emp_no.remove(ind);
		System.out.println("Item deleted succssefully");
	}
	private static void viewer() {
		// TODO Auto-generated method stub
		Main myobj= new Main();
		System.out.println("Emp Name Emp_No");
		for(int i = 1; i<myobj.emp_name.size();i++) {
			System.out.println(myobj.emp_name.get(i)+" "+myobj.emp_no.get(i));
		}
	}
	private static void adder() {
		// TODO Auto-generated method stub
		System.out.println("Enter Name and Id");
		Scanner sc = new Scanner(System.in);
		String name= sc.nextLine();
		int id = sc.nextInt();
		Main myobj= new Main();
		myobj.emp_name.add(name);
		myobj.emp_no.add(id);
		System.out.println("Item added succssefully");
		System.out.println("Emp Name Emp_No");
		for(int i = 1; i<myobj.emp_name.size();i++) {
			System.out.println(myobj.emp_name.get(i)+" "+myobj.emp_no.get(i));
		}
	}
	public static int menu() {
		System.out.print("1: Enter Employee information \n 2:See Employee information \n 3: Remove employee information");
		Scanner sc = new Scanner(System.in);
		int res= sc.nextInt();
		return res;
	}

}
